<!-- SPDX-License-Identifier: MPL-2.0 -->

# MCP 逐工具覆盖

这是计划映射，不是运行结果。HTTP 和 stdio 每个内置工具均须实际 tools/call 及断言。

动态工具数不固定。Terminal 按真实 run/start 契约测试；HTTP 覆盖 GET/JSON/Form 及公开和私密参数；上游 stdio/HTTP 服务分别发现后逐操作调用。每次授权、修改、归档、恢复后重新 tools/list。新工具未映射需列为覆盖缺口，不能只核对静态数量 30。

| Tool | HTTP cases | stdio cases |
| --- | --- | --- |
| Lumi.get_context | CON-01 | CON-01 |
| Lumi.list_capabilities | CON-02 | CON-02 |
| Lumi.create_capability_draft | TOOL-02 | TOOL-02 |
| Lumi.list_tasks | TERM-02, RUN-04 | TERM-02, RUN-04 |
| Lumi.get_task | TERM-02, TERM-07, RUN-04 | TERM-02, TERM-07, RUN-04 |
| Lumi.stop_task | TERM-07 | TERM-07 |
| Lumi.restart_task | TERM-07 | TERM-07 |
| Lumi.get_workbench_template | HOME-02 | HOME-02 |
| Lumi.get_workbench | HOME-02, HOME-04 | HOME-02, HOME-04 |
| Lumi.publish_workbench | HOME-04 | HOME-04 |
| Lumi.list_workbench_versions | HOME-07 | HOME-07 |
| Lumi.restore_workbench_version | HOME-07 | HOME-07 |
| Lumi.export_workbench_project | HOME-08 | HOME-08 |
| Lumi.knowledge_get_contract | KB-02 | KB-02 |
| Lumi.knowledge_list | KB-02 | KB-02 |
| Lumi.knowledge_create | KB-02 | KB-02 |
| Lumi.knowledge_compare | KB-03, KB-08 | KB-03, KB-08 |
| Lumi.knowledge_prepare_build | KB-04, KB-08 | KB-04, KB-08 |
| Lumi.knowledge_begin_build | KB-04, KB-08, KB-09 | KB-04, KB-08, KB-09 |
| Lumi.knowledge_write_batch | KB-04, KB-08, KB-09, KB-10, KB-17 | KB-04, KB-08, KB-09, KB-10, KB-17 |
| Lumi.knowledge_get_build | KB-04, KB-09, KB-10, KB-17 | KB-04, KB-09, KB-10, KB-17 |
| Lumi.knowledge_validate_build | KB-04, KB-08, KB-10 | KB-04, KB-08, KB-10 |
| Lumi.knowledge_publish_build | KB-04, KB-08, KB-09 | KB-04, KB-08, KB-09 |
| Lumi.knowledge_cancel_build | KB-17 | KB-17 |
| Lumi.knowledge_read | KB-05 | KB-05 |
| Lumi.knowledge_search | KB-06 | KB-06 |
| Lumi.knowledge_graph | KB-06 | KB-06 |
| Lumi.search_skills | SK-04 | SK-04 |
| Lumi.get_skill | SK-05 | SK-05 |
| Lumi.read_skill_file | SK-05 | SK-05 |
