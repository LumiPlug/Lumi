<!-- SPDX-License-Identifier: MPL-2.0 -->

# 宿主接口与公开功能的对应

这些接口索引用于辅助定位及负向权限测试，不将接口调用冒充原生点击。部分保留接口没有当前 UI 入口，应标 API-only 兼容专项，不能编造按钮。

| 接口族 | 操作 | 原生或协议入口 |
| --- | --- | --- |
| tools | list/tasks/task/stop/restart/get/save/check/discover/enable/disable/archive/restore/prepare/run | 工具页、运行窗；当前没有独立 disable 按钮，撤销授权正向走修改保存/归档 |
| capabilities | drafts、enable/disable | MCP create_capability_draft；仅 MCP token 调宿主管理做 CON-08 负向 |
| skills | list/scan/import/directory/file/project/archive | Skills 原生界面；project 是保留接口，当前页面不提供新增扫描项目入口 |
| knowledge | list/view/create/evidence/graph/search/import/archive/cancel/takeover/restore/export | 知识库原生操作；14 个 AI 工具另测，不能替代 UI 接管/导出/导入 |
| workbench | get/versions/publish/restore/export/rpc | MCP 发布/历史/源码；原生 iframe 显示及 SDK，无原生发布按钮 |
| mcp | token/check、读取配置、设置端口 | 设置页真实点击，再用复制配置连接 |
| native | Core状态、复制、打开链接/目录、运行窗与关闭策略 | CUA 宿主操作；nonce 与非宿主请求做负向 |

主页 SDK 公开面逐个测试：context.get、capabilities.list、tools.list/call、storage.get/set/delete、theme.get/subscribe、toast.show。通过 fixture 主页按钮在真实 APP iframe 中调用；Skills/Knowledge 原生管理不属于当前 SDK 承诺。

Skills MCP 安装和 Memory 是当前功能缺口。Browser MCP 等设想若当前目录不存在，记录未实现，不凭远期产品文档编造工具。

每轮 `session.mjs inventory` 登记两传输目录；`record` 中 toolCalls 保存实际成功、预期拒绝或不匹配及证据。工具名覆盖、参数变体及用户旅程分别统计。
