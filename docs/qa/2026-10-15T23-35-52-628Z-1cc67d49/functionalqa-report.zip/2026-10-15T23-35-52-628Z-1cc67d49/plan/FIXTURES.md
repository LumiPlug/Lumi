<!-- SPDX-License-Identifier: MPL-2.0 -->

# 无害业务 fixture 与清理约定

每轮 `runs/<runId>/private/` 保存连接配置、resumeToken、完整私密断言材料，不在可查看报告中链接它们。`evidence/` 只存脱敏截图/协议/账本，`fixtures/` 是本轮可删除材料。测试前验证真实数据目录，准备 objects.json 登记本轮对象。

| fixture | 内容与行为 | 核验 |
| --- | --- | --- |
| Terminal | 中文空格目录；回显argv/cwd/公开环境；独立私密哨兵；stdout/stderr/退出7；可取消子孙进程和loopback端口；大量日志 | 参数顺序、哨兵脱敏、PID树/端口、调用次数，不接触用户项目 |
| HTTP | loopback随机端口；GET/query、JSON、Form；结构化false/0/空/数组，文本、空响应、503、延迟、取消 | 请求方法/头/正文账本；每个requestId出现次数；不自动重放 |
| 上游MCP | 独立stdio和HTTP服务；多操作/分页/重复cursor；显式和缺失outputSchema；Schema动态变更；错误/延迟/通知/取消 | initialize/list/call时间及PID；并发不误杀；16会话边界；真实空闲计时 |
| Skills | 有效SKILL.md、引用文档/脚本/图片/二进制；同物理多来源及同名异源；无效、符号链接、13层/2001项/33MiB | 原源与托管hash/权限、脚本未执行标记、staging无残留；删除仅限本轮源 |
| Home | 两种UI提示词共用的官方静态模板；runId可视标题；逐项SDK测试按钮；项目A/B；版本1/2；过期frame和无效bundle | 原生iframe显示与点击、工具账本、KV隔离、旧frame拒绝、源码hash |
| Knowledge | 非Git和两Git分支；文档父子树、节点/边/引用；full和incremental；缺引用/循环；seq/token/revision冲突 | published revision、五种read、search/graph、UI正文/图谱/证据、导出hash |

外部 HTTP/上游 MCP fixture 可以由本地 Node 辅助脚本提供；Lumi 必须是被测原生 APP 自己的 Core。配置中的 Node 路径仅用于 fixture，不证明用户安装 Lumi 需要 Node。

Terminal没有统一执行截止；HTTP按配置（默认30秒、最大300秒），上游MCP执行300秒、stdio默认310秒可配置等待，分别验证。空闲 5 分钟回收不能通过假时钟代替；活动测试在合法执行期限内观察，若要跨 5 分钟覆盖“持续活动”可用重叠、各自小于截止时间的真实调用，使连接始终有活动请求。上游MCP超过300秒的单调用按超时契约记录，不自动算空闲回收失败。

objects.json 至少包含：appPath、appIdentifier、dataRoot、Core PID、能力/任务/技能/kb/projectId、修改前设置、创建文件、fixture服务PID/端口及清理状态。停止仅限登记进程，禁止 killall/pkill。若不能证明对象属于本轮，保留并在报表写待人工确认。

清理顺序：停止本轮任务→恢复主页/设置/主题（若测试当前用户APP）→归档或删除本轮业务fixture→停止本轮fixture服务→退出独立测试APP→核对PID/端口→处理本轮目录。不要清理任何真实客户端技能或用户知识库。恢复失败本身列为失败或阻断，不能静默结束。
