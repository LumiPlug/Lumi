<!-- SPDX-License-Identifier: MPL-2.0 -->

# 真实 APP 用户旅程执行手册

前置：冻结 runId、APP 路径/版本、Core PID/端口和数据目录；所有对象名带 `qa-<runId>`。两种 MCP 配置从这个 APP 复制，保存在 private/。下文 HTTP/stdio 分别执行并独立留证；共享同一对象时明确当前版本，不能自动重放写入。

## 1. 首次使用与外部 AI 连接

CUA 打开工作台，无主页时观察引导；未发生外部访问先点开始使用，应得到正确提示。设置里复制两种配置，用 SDK 分别 initialize、tools/list、get_context。回到 APP 确认外部访问时间、引导进入模板。自检只证明探针连通，不算外部 AI 已访问。分别试模板页“完成”进入later状态、点击“配置工作台”重新开始、模板选择与提示词复制。

证据：引导前后原生截图、脱敏配置 hash、两传输握手/上下文和目录、对应 Core/对象身份。对应 SET、CON、HOME-01。

## 2. AI 草稿 → 原生授权 → 三种工具真实执行

分别用 MCP `create_capability_draft` 创建 Terminal/HTTP/MCP fixture 草稿；立即查看目录与副作用，不能已经执行。CUA 打开该草稿，HTTP先补齐fixture URL，MCP先补齐连接并发现真实工具，保存后再审阅参数、隐藏字段和目标，确认启用。重新 tools/list，调用本轮动态操作，逐项对齐 fixture 账本与 APP 结果。

Terminal 以实际动态目录为准区分 run/start 和 taskId；HTTP/MCP 保留同步结果，不强行要求统一异步接口。MCP 发起任务后从 UI 停止；UI 发起后由 MCP stop_task/restart_task，检查新旧任务。查看配置快照、日志、复制和历史重开；HTTP/MCP另检查原始数据与结构化面板，Terminal核对日志和退出码。

CUA 修改已授权配置并保存，应撤销授权；旧入口调用拒绝，再审阅启用。归档应从 AI 可用目录消失，恢复为草稿；已有任务状态单独确认。当前没有独立“禁用”按钮时，以真实的修改/归档路径验证，API-only disable 单独记专项，不虚构按钮。

负向越权专项：仅用 MCP token 调 /app/tools save/enable/run 和 /app/capabilities/:id/enable，目标仅本轮无害 fixture。若能绕过审阅，记 FAIL，保存具体请求/结果/副作用并恢复；不使用此方式完成正向授权。

## 3. Skills 托管 → AI 按需读取 → 归档与恢复

在支持的 fixture 客户端根目录放技能，CUA 重新扫描、来源分类/搜索、查看日期和详情。主文件引用文本、代码、图片及脚本附件；打开相对链接和复制路径，确认脚本未执行。

通过当前真实导入入口输入完整路径，或从发现详情导入。核验 Lumi 托管标签与复制 hash/权限。两传输 search_skills→get_skill→read_skill_file，覆盖分页、图片/二进制/超大和不存在文件。删除的只能是本轮原始 fixture，随后重启 APP 再读托管副本。

CUA 归档后，两个已连接客户端重新搜索、取说明和附件均应受控；恢复后再读。异常包必须通过 UI 导入路径至少验证代表项，完整限额可辅以同 APP 宿主负向请求，但不能替代 UI 操作证据。

另记录 AI 期望的 `install_skill` 当前不存在。正确拒绝是现状边界验证，报表仍写“AI 安装 Skills 未实现”。

## 4. AI 开发主页 → MCP 发布 → 原生 iframe 使用 SDK

CUA 选择工作助手/功能入口并复制提示词；MCP get_workbench_template（两种UI提示词共用同一静态工程，无模板选择参数）、get_workbench 取入口、源码、expectedVersion 和 SDK 契约。开发 fixture 主页包含 runId 标题，以及 context、capabilities、tools、storage、theme、toast 测试按钮。publish_workbench 后回到真实 APP，必须看见新内容并点击。

点击工具按钮执行已经 CUA 授权的 fixture，对照任务 id、source=workbench 和账本。主题订阅实际随设置变化；KV 同项目升级和重启保留，新 projectId 不可见旧项目数据。主页 SDK 当前未公开 Skills/Knowledge 原生管理接口，不能绕过宿主来伪造它支持全部 MCP；如目标需要这些能力就记功能缺口，或经已授权公开工具提供必要业务数据。

发布旧 expectedVersion 和无效包，确认当前页不被覆盖。list_workbench_versions→读取 v1→restore 到新版本 v3，APP 显示 v1 内容，历史和同项目 KV 保留。测试旧 frame、离开主页后的调用拒绝。导出当前/历史源码到本轮目录，非空目录拒绝；取回 bundle 再发布，实际显示。当前没有原生“发布/导入主页”按钮，不编造 UI 步骤。

## 5. 原生新建知识库 → AI 构建 → 原生阅读图谱与引用

CUA 新建非 Git 和 Git(main/feature) 分组；MCP get_contract、list/create 对齐 projectKey/branch。compare→prepare_build→begin_build(full)→write_batch(文档树/节点/关系/引用)→get_build→validate_build→get_build(validated)→publish_build。每个工具在两传输均有真实断言，第二传输使用独立构建或明确共享状态。

CUA 查看同一 kbId/revision：目录、正文、节点跳转、邻域展开、关系证据、来源弹窗、搜索命中定位；与 knowledge_read 的 outline/document/node/evidence/version_summary 五种 target、search 分页、graph overview/neighborhood 对照。引用元信息来自外部提交，不宣称 Lumi 已读取源文件或验证语义正确。

增量构建新增/改/显式删除形成 v2，另一分支不变。历史查看和恢复产生新 revision。CUA 导出 JSON 并经原生文件入口重新导入，核对 hash 和新版本；坏包不覆盖。

## 6. 构建取消、接管、归档和重启续建

一次 MCP cancel_build 后看 UI；另一次从 UI 停止后让旧写入者继续，均应拒绝。CUA 接管构建，新凭证只在 private/；旧 token 失败，新 token 接续同 build/seq，重新校验后发布。

CUA 归档时两传输 list/read/search/graph/写入均按边界拒绝，恢复保留历史。writing 和 validating 分别重启 APP，确认可续建状态，必要时重新校验。并发取消/归档/接管/重复发布不覆盖最新状态。Worker 故障专项只辅助定位，不能顶替这些用户操作。

## 7. 日常使用与恢复

工具、技能、主页、知识库均有本轮数据后，记录基线。CUA 关闭运行窗分别选择取消/后台/停止；主窗关闭与恢复，不丢输入和需保留页面。隐藏/最小化与失焦分别观察，恢复即同步。

先保存端口：当前endpoint仍有效并显示重启说明；重启后新端口双传输有效，旧端口不可达。再在同端口刷新令牌：旧HTTP/stdio令牌立即拒绝，新配置立即可用；普通重启保留新令牌。每次对照本轮对象、版本和KV，不混淆端口不可达与认证拒绝。安全页真实 5 分钟释放单独观察，不在等待中主动激活 APP。最后显式 Quit，核验本轮进程/端口与设置恢复，结束报表。

## 每条旅程的最小证据包

`before-native`、`action-native`、`after-native`；两传输脱敏工具调用及逐项断言；对象/任务/版本关联；fixture 实际副作用；需要重启的前后对照；清理账本。缺某一段就写部分完成，不能以“协议已通过”将整条旅程记 PASS。
